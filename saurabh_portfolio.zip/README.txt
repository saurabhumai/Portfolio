Portfolio for Saurabh Virendra Yadav

Files:
- index.html
- about.html
- projects.html
- contact.html
- styles.css
- script.js

To preview:
1. Unzip the file.
2. Open index.html in your browser.

The site includes a 'Download ZIP' link in the navigation and contact page for convenience.
